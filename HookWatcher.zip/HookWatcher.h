// HookWatcher.h : main header file for the HookWatcher DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CHookWatcherApp
// See HookWatcher.cpp for the implementation of this class
//

class CHookWatcherApp : public CWinApp
{
public:
	CHookWatcherApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
